package com.penthouse_bogmjary;

public class FolderData {
    String buildingAddress;

    public String getBuildingAddress(){
        return buildingAddress;
    }
    public void setBuildingAddress(String buildingAddress){
        this.buildingAddress = buildingAddress;
    }
}
